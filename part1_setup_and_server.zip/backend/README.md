# LMS Backend

Express + MongoDB (Mongoose) backend for the Learning Management System.

## Current features
- User signup (`POST /api/auth/signup`) with bcrypt password hashing

## Setup
1. `npm install`
2. Copy `.env.example` to `.env` and put your real `MONGODB_URI`
3. `npm start` (server runs on port 9000)

## Test signup
POST http://localhost:9000/api/auth/signup
Body (JSON): { "name": "Ali", "email": "ali@example.com", "password": "123456" }

## Folder structure
- config/      database connection
- models/      mongoose schemas
- controller/  request handling logic
- route/       express routes
- server.js    app entry point
