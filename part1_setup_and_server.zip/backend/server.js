import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import connectdb from "./config/db.js";
import authRoute from "./route/authRoutes.js";

dotenv.config();

const app = express();

connectdb();

app.use(cors({
    origin: "http://localhost:5173",
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true
}));

app.use(express.json());

app.use("/api/auth", authRoute);

app.get("/", (req, res) => {
    res.send("Welcome to the LMS Home Page!");
});

app.listen(9000, () => {
    console.log("Server is running on port 9000");
});
