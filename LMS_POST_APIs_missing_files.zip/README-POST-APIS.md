# LMS POST APIs — implementation package

## Important note about the source ZIP
The supplied LMS ZIP contains the server setup archive and an auth route/controller fragment, but it does **not** contain actual model files for Course, Enrollment, Assignment, Submission, Quiz, QuizAttempt, or Announcement. The files in this package therefore provide a consistent starter implementation for common LMS entities, not a verified reconstruction of model definitions absent from the ZIP. Compare the proposed schemas with your team's actual database/model requirements before merging.

## Setup
1. Back up your current backend.
2. Copy the `backend/` files into the backend directory of your repository (merge folders; do not replace unrelated frontend files).
3. Run `npm install` inside `backend/`.
4. Copy `.env.example` to `.env` and set `MONGODB_URI`.
5. Run `npm start`.

## POST endpoints
All routes expect `Content-Type: application/json`.

| Method | Endpoint | Required body fields |
|---|---|---|
| POST | `/api/auth/signup` | `name`, `email`, `password` |
| POST | `/api/users` | `name`, `email`, `password` |
| POST | `/api/courses` | `title`, `code`, `instructor`, `credits` |
| POST | `/api/enrollments` | `student`, `course` |
| POST | `/api/assignments` | `course`, `title`, `description`, `dueDate`, `maxMarks`, `createdBy` |
| POST | `/api/submissions` | `assignment`, `student`, `submissionUrl` |
| POST | `/api/quizzes` | `course`, `title`, `questions`, `createdBy` |
| POST | `/api/quiz-attempts` | `quiz`, `student` |
| POST | `/api/announcements` | `title`, `message`, `createdBy` |

`instructor`, `student`, `course`, `assignment`, `quiz`, and `createdBy` values must be valid MongoDB ObjectId strings referencing existing records. Create parent records first. `questions` is an array of objects shaped like `{ "questionText": "...", "options": ["A", "B"], "correctOptionIndex": 0, "marks": 1 }`.

## Example requests
### Course
```json
{
  "title": "Introduction to Programming",
  "code": "CS101",
  "description": "Programming fundamentals",
  "instructor": "REPLACE_WITH_USER_OBJECT_ID",
  "credits": 3
}
```

### Assignment
```json
{
  "course": "REPLACE_WITH_COURSE_OBJECT_ID",
  "title": "Lab 1",
  "description": "Submit the first lab task.",
  "dueDate": "2026-11-15T23:59:00.000Z",
  "maxMarks": 10,
  "createdBy": "REPLACE_WITH_TEACHER_OBJECT_ID"
}
```

## Response conventions
- `201 Created`: record successfully created.
- `400 Bad Request`: required field, schema validation, or ObjectId error.
- `409 Conflict`: duplicate unique record.
- `500 Internal Server Error`: unexpected server error.

## Before production
These starter POST endpoints do not implement login/session/JWT authentication or role-based authorization. Protect teacher/admin creation endpoints before public deployment. Do not allow clients to assign privileged roles; public user creation is restricted to `student`. Quiz schema stores correct answers and should not be returned from a public quiz-reading endpoint without filtering.
