import express from "express";
import { createQuizAttempt } from "../controllers/quizAttemptController.js";

const router = express.Router();
router.post("/", createQuizAttempt);

export default router;
