import "dotenv/config";
import express from "express";
import cors from "cors";
import connectDB from "./config/db.js";

import authRoutes from "./route/authRoutes.js";
import userRoutes from "./route/userRoutes.js";
import courseRoutes from "./route/courseRoutes.js";
import enrollmentRoutes from "./route/enrollmentRoutes.js";
import assignmentRoutes from "./route/assignmentRoutes.js";
import submissionRoutes from "./route/submissionRoutes.js";
import quizRoutes from "./route/quizRoutes.js";
import quizAttemptRoutes from "./route/quizAttemptRoutes.js";
import announcementRoutes from "./route/announcementRoutes.js";

const app = express();
app.use(cors({
  origin: process.env.CLIENT_ORIGIN || "http://localhost:5173",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
  credentials: true
}));
app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => res.json({ message: "LMS API is running" }));
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/enrollments", enrollmentRoutes);
app.use("/api/assignments", assignmentRoutes);
app.use("/api/submissions", submissionRoutes);
app.use("/api/quizzes", quizRoutes);
app.use("/api/quiz-attempts", quizAttemptRoutes);
app.use("/api/announcements", announcementRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error" });
});

const PORT = Number(process.env.PORT || 9000);
try {
  await connectDB();
  app.listen(PORT, () => console.log(`LMS API listening on port ${PORT}`));
} catch (error) {
  console.error("Could not start LMS API:", error.message);
  process.exit(1);
}
