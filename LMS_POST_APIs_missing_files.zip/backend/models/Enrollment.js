import mongoose from "mongoose";

const enrollmentSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true },
  status: { type: String, enum: ["enrolled", "completed", "withdrawn"], default: "enrolled" }
}, { timestamps: true });

enrollmentSchema.index({ student: 1, course: 1 }, { unique: true });
export default mongoose.models.Enrollment || mongoose.model("Enrollment", enrollmentSchema);
